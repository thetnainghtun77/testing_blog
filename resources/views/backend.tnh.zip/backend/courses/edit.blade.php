@extends('backendtemplate')

@section('content')

	<div class="container-fluid">
		<h2>Show with Form/ Old value</h2>
		@if ($errors->any())
		<div class="alert alert-danger">
			<ul>
				@foreach ($errors->all() as $error)
				<li>{{ $error }}</li>
				@endforeach
			</ul>
		</div>
		@endif
		<div class="row">
			<form method="post" action="{{route('courses.update',$course->id)}}" enctype="multipart/form-data">
				@csrf
				@method('PUT')
				<div class="form-group row">
					<label for="name" class="col-sm-2 col-form-label">Name</label>
					<div class="col-sm-10">
						<ul class="nav nav-tabs">
							<li class="nav-item">
								<a href="#" class="nav-link active" data-toggle="tab">Old</a>
							</li>
							<li class="nav-item">
								<a href="#" class="nav-link" data-toggle="tab">New</a>
							</li>
						</ul>
						<div class="tab-content py-3">
							<div class="tab-pane fade show active" id="old">
								<img src="{{asset($course->logo)}}" class="img-fluid w-25">
								<input type="hidden" name="oldlogo" value="{{$course->logo}}">
							</div>
							<div class="tab-pane fade" id="new">
								<input type="file" class="form-control-file" id="inputLogo" name="logo">
							</div>
						</div>
						<input type="text" name="name" class="form-control" id="name" value="{{$course->name}}">
					</div>
				</div>
				<div class="form-group row">
					<label for="inputLogo" class="col-sm-2 col-form-label">Logo</label>
					<div class="col-sm-10">
						<input type="file" class="file-control" name="logo" id="inputLogo">
					</div>
				</div>			
				<div class="form-group row">
					<label for="outline" class="col-sm-2 col-form-label">Outline</label>
					<div class="col-sm-10">
						<textarea type="text" class="form-control" name="outlines" id="outlines">{{$course->outline}}</textarea>
					</div>
				</div>
				<div class="form-group row">
					<label for="name" class="col-sm-2 col-form-label">Fees</label>
					<div class="col-sm-10">
						<input type="number" name="fees" class="form-control" id="fees" value="{{$course->fees}}">
					</div>
				</div>
				<div class="form-group row">
					<label for="name" class="col-sm-2 col-form-label">During</label>
					<div class="col-sm-10">
						<input type="text" name="during" class="form-control" id="during" value="{{$course->during}}">
					</div>
				</div>
				<div class="form-group row">
					<label for="name" class="col-sm-2 col-form-label">Duration</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="duration" id="duration" value="{{$course->duration}}">
					</div>
				</div>
				<div class="form-group row">
					<div class="col-sm-10">
						<button type="submit" class="btn btn-primary">Update</button>
					</div>
				</div>
			</form>
		</div>
	</div>

@endsection